# 教室管理系统

## 环境

>OS: Ubuntu 20.04 LTS x86_64
>
>Host: 20SM Lenovo ThinkBook 15-IIL
>
>Kernel: 5.4.0-26-generic
>
>CPU: Intel i7-1065G7 (8) @ 3.900GHz
>
>GPU: Intel Iris Plus Graphics G7
>
>Qt Creator 4.12.2 based on Qt 5.14.2
>
>mysql  Ver 14.14 Distrib 5.7.42, for Linux (x86_64) using  EditLine wrapper

## 时间线

>230410 项目开跑，sql第一版,登录页面,学生功能选择，教师功能选择，管理员功能选择 四个ui

>230411 非并发登录功能 输入验证

>230418 更新主页面 左侧栏目 页面变大变小 全局按钮 复选按钮登录验证
>
>230429 管理员页面完成
>
>230501 学生页面完成
>
>230507 完善UI和教师，教室，学生信息查询，更新sql 添加表loginRecord studentClassInfo
>
>230515 一周没看，看不懂屎山了
>
>230519 偶尔回顾，能看懂逻辑了
>
>230522 学生提交审核
>
>~~230526 管理审核申请~~
>
>~~230528 管理员发布公告~~